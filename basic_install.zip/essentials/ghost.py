import webbrowser
import time
import pyautogui
import os
import getpass
import threading
import subprocess

# -----------------------------
# Funktion för att låsa musen
# -----------------------------
def lock_mouse(stop_event):
    x, y = pyautogui.position()  # spara startposition
    while not stop_event.is_set():
        pyautogui.moveTo(x, y)
        time.sleep(0.01)

# Starta muslåstråden
stop_event = threading.Event()
mouse_thread = threading.Thread(target=lock_mouse )
mouse_thread.start()

# -----------------------------
# Öppna Google
# -----------------------------
webbrowser.open("https://www.google.com")
time.sleep(3)
pyautogui.write("exempelord", interval=0.1)
time.sleep(1)

# -----------------------------
# Öppna ny flik: Google Search History
# -----------------------------
pyautogui.hotkey('ctrl', 't')
time.sleep(1)
pyautogui.write("https://myactivity.google.com/myactivity")
pyautogui.press("enter")
time.sleep(3)

# -----------------------------
# Öppna ny flik: CrazyGames
# -----------------------------
pyautogui.hotkey('ctrl', 't')
time.sleep(1)
pyautogui.write("https://www.crazygames.com")
pyautogui.press("enter")
time.sleep(3)

# -----------------------------
# Öppna Windows-inställningar → lösenordsinställningar
# -----------------------------
pyautogui.hotkey('win', 'i')
time.sleep(2)
pyautogui.write("password windows", interval=0.1)
time.sleep(1)
pyautogui.press("enter")
time.sleep(2)

# -----------------------------
# Öppna terminalen (CMD) via Win+R
# -----------------------------
pyautogui.hotkey('win', 'r')
time.sleep(1)
pyautogui.write("cmd")
pyautogui.press("enter")
time.sleep(2)

# -----------------------------
# Skriv text i terminalen med användarnamnet och radera
# -----------------------------
user_name = getpass.getuser()
text_to_write = f"Jag ser dig, {user_name}"

pyautogui.write(text_to_write, interval=0.1)
time.sleep(1)
pyautogui.press("backspace", presses=len(text_to_write))
time.sleep(0.5)

# -----------------------------
# Kör apperance_back.py som finns i hckerpack-mappen
# -----------------------------
desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
hckerpack_path = os.path.join(desktop_path, "hckerpack")
apperance_script = os.path.join(hckerpack_path, "apperance_back.py")

if os.path.exists(apperance_script):
    subprocess.Popen(["python", apperance_script])
else:
    print("Filen apperance_back.py finns inte i hckerpack-mappen.")

# -----------------------------
# Avsluta muslåstråden
# -----------------------------
stop_event.set()
mouse_thread.join()

# -----------------------------
# Starta om datorn
# -----------------------------
os.system("shutdown /r /t 5")

print("Klar! Alla steg är genomförda, musen var låst under körning, och datorn startas om om 5 sekunder.")
