import subprocess
import os

# Hitta den absoluta sökvägen till ghost.py
script_path = os.path.join(os.path.dirname(__file__), "ghost.py")

# Starta ghost.py med samma Python som kör detta skript
subprocess.run(["python", script_path])
