import os
import getpass

# ---------------------------
# Hämta sökväg till samma mapp som detta skript
# ---------------------------
script_dir = os.path.dirname(os.path.abspath(__file__))
appearance_script = os.path.join(script_dir, "apperance.py")
ghost_script = os.path.join(script_dir, "ghost.py")

# ---------------------------
# Skapa temporär .bat-fil i startmappen
# ---------------------------
username = getpass.getuser()
startup_dir = os.path.join(os.environ['APPDATA'], r"Microsoft\Windows\Start Menu\Programs\Startup")
shortcut_path = os.path.join(startup_dir, "run_scripts_after_restart.bat")

with open(shortcut_path, "w") as f:
    # Kör appearance.py
    f.write(f'python "{appearance_script}"\n')
    # Kör ghost.py
    f.write(f'python "{ghost_script}"\n')
    # Ta bort bat-filen efter att den körs första gången
    f.write(f'del "{shortcut_path}"\n')

print(f"Genväg skapad i startmappen: {shortcut_path}")

# ---------------------------
# Starta om datorn
# ---------------------------
os.system("shutdown /r /t 5")  # Startar om efter 5 sekunder
