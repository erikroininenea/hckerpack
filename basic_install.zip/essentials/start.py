import os
import getpass
import time
import sys

# ---------------------------
# Hämta sökväg till samma mapp som detta skript
# ---------------------------
script_dir = os.path.dirname(os.path.abspath(__file__))
appearance_script = os.path.join(script_dir, "apperance.py")
ghost_script = os.path.join(script_dir, "start_ghost.py")

# ---------------------------
# Skapa .bat-fil i startmappen
# ---------------------------
username = getpass.getuser()
startup_dir = os.path.join(
    os.environ['APPDATA'], 
    r"Microsoft\Windows\Start Menu\Programs\Startup"
)
shortcut_path = os.path.join(startup_dir, "run_scripts_after_restart.bat")

try:
    with open(shortcut_path, "w") as f:
        # Kör ghost.py först
        f.write(f'python "{ghost_script}"\n')
        # Kör appearance.py efter
        f.write(f'python "{appearance_script}"\n')
        # Ta bort bat-filen efter att den körs första gången
        f.write(f'del "{shortcut_path}"\n')
except Exception as e:
    print(f"Fel: Kunde inte skapa startup-fil ({e})")
    sys.exit(1)

# ---------------------------
# Kontrollera att filen verkligen skapades
# ---------------------------
if not os.path.exists(shortcut_path):
    print("Fel: Startup-fil skapades inte. Avbryter omstart.")
    sys.exit(1)
else:
    print(f"Genväg skapad i startmappen: {shortcut_path}")

# ---------------------------
# Säkerhetskontroll: se till att ghost.py finns
# ---------------------------
if not os.path.exists(ghost_script):
    print("VARNING: ghost.py hittades inte! Omstart avbruten.")
    sys.exit(1)

# ---------------------------
# Starta om datorn
# ---------------------------
print("Systemet startar om om 5 sekunder...")
time.sleep(2)
os.system("shutdown /r /t 5")
