import ctypes
import winreg
import os
import json
import ctypes

# Hämta sökväg till skriptets mapp
script_dir = os.path.dirname(os.path.abspath(__file__))
cursor_dir = os.path.join(script_dir, "cursor")      # Mappen med cursors
images_dir = os.path.join(script_dir, "images")      # Mappen med bakgrundsbilder

# ---------------------------
# Spara nuvarande inställningar
# ---------------------------
reg_path = r"Control Panel\Cursors"
backup_file = os.path.join(script_dir, "appearance_backup.json")  # ändrat namn
backup_data = {}

# Spara muspekare
with winreg.OpenKey(winreg.HKEY_CURRENT_USER, reg_path, 0, winreg.KEY_READ) as key:
    for cursor_name in ["Arrow", "AppStarting", "Hand", "IBeam", "SizeAll"]:
        try:
            value, _ = winreg.QueryValueEx(key, cursor_name)
            backup_data[cursor_name] = value
        except FileNotFoundError:
            pass

        # Hämta handtaget till skrivbordets ListView
hwnd = ctypes.windll.user32.FindWindowW("Progman", None)
desktop = ctypes.windll.user32.FindWindowExW(hwnd, 0, "SHELLDLL_DefView", None)
listview = ctypes.windll.user32.FindWindowExW(desktop, 0, "SysListView32", None)

# FLAGGOR
SW_HIDE = 0
SW_SHOW = 5

# Dölj ikonerna
ctypes.windll.user32.ShowWindow(listview, SW_HIDE)

print("Skrivbordsikonerna är nu osynliga!")

# Spara bakgrund
current_bg = ctypes.create_unicode_buffer(260)
ctypes.windll.user32.SystemParametersInfoW(0x0073, 260, current_bg, 0)
backup_data["background"] = current_bg.value

# Skriv backup till fil
with open(backup_file, "w", encoding="utf-8") as f:
    json.dump(backup_data, f, ensure_ascii=False, indent=4)

# ---------------------------
# Ändra bakgrundsbild
# ---------------------------
bakgrund = os.path.join(images_dir, "bg.png")  # bakgrund i images/

if os.path.exists(bakgrund):
    ctypes.windll.user32.SystemParametersInfoW(20, 0, bakgrund, 3)
else:
    print("Bakgrundsbild saknas:", bakgrund)

# ---------------------------
# Ändra muspekare
# ---------------------------
cursors = {
    "Arrow": "default.cur",
    "AppStarting": "loading.cur",
    "Hand": "hand.cur",
    "IBeam": "text.cur",
    "SizeAll": "move.cur",
}

SPI_SETCURSORS = 0x0057
SPIF_UPDATEINIFILE = 0x01
SPIF_SENDCHANGE = 0x02

for cursor_name, file_name in cursors.items():
    path = os.path.join(cursor_dir, file_name)
    if os.path.exists(path):
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, reg_path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, cursor_name, 0, winreg.REG_SZ, path)
    else:
        print(f"Pekare saknas: {file_name}")

ctypes.windll.user32.SystemParametersInfoW(SPI_SETCURSORS, 0, None, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE)
print("Bakgrundsbild och muspekare uppdaterade och backup sparad som appearance_backup.json!")
