import ctypes
import winreg
import os
import json

# Hämta sökväg till skriptets mapp
script_dir = os.path.dirname(os.path.abspath(__file__))
backup_file = os.path.join(script_dir, "appearance_backup.json")

if not os.path.exists(backup_file):
    print("Ingen backupfil hittad!")
    exit()

# Läs backupfil
with open(backup_file, "r", encoding="utf-8") as f:
    backup_data = json.load(f)

# ---------------------------
# Återställ bakgrund
# ---------------------------
background = backup_data.get("background")
if background:
    ctypes.windll.user32.SystemParametersInfoW(20, 0, background, 3)

# ---------------------------
# Återställ muspekare
# ---------------------------
SPI_SETCURSORS = 0x0057
SPIF_UPDATEINIFILE = 0x01
SPIF_SENDCHANGE = 0x02
reg_path = r"Control Panel\Cursors"

for cursor_name, path in backup_data.items():
    if cursor_name == "background":
        continue
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, reg_path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, cursor_name, 0, winreg.REG_SZ, path)
    except Exception as e:
        print(f"Kunde inte återställa {cursor_name}: {e}")

ctypes.windll.user32.SystemParametersInfoW(SPI_SETCURSORS, 0, None, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE)

# ---------------------------
# Visa skrivbordsikoner igen
# ---------------------------
SW_SHOW = 5

hwnd = ctypes.windll.user32.FindWindowW("Progman", None)
desktop = ctypes.windll.user32.FindWindowExW(hwnd, 0, "SHELLDLL_DefView", None)
listview = ctypes.windll.user32.FindWindowExW(desktop, 0, "SysListView32", None)

if listview:
    ctypes.windll.user32.ShowWindow(listview, SW_SHOW)
    print("Skrivbordsikonerna är nu synliga igen!")
else:
    print("Kunde inte hitta skrivbordsikonerna.")

print("Alla inställningar återställda!")
